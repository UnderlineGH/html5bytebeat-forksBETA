import Visualizer from './Visualizer.js';

export default class NullVisualizer extends Visualizer {
  constructor(canvas) {
    super(canvas);
  }
}