/* global LZMA */

const compressor = new LZMA( 'js/lzma_worker.js' );
export default compressor;